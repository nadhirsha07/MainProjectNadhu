import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-girls',
  templateUrl: './girls.component.html',
  styleUrls: ['./girls.component.css']
})
export class GirlsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
