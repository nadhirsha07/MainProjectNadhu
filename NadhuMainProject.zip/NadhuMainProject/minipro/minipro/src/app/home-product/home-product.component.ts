import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Component({
  selector: 'app-home-product',
  templateUrl: './home-product.component.html',
  styleUrls: ['./home-product.component.css']
})
export class HomeProductComponent implements OnInit {
  msg;
  message;
  dress;
  brand;
  prize:Number = 0;
  constructor(private http:HttpClient) { }

  ngOnInit() {
  }
  AddProduct(){ 
    var url="http://localhost:8000/insert";
    var data={dress:this.dress, brand:this.brand,prize:this.prize};
    this.http.post(url, data).subscribe(data=>{
      console.log(data);
      this.message = data;
    })

  }
  imageUrl:string="assets/images/image2.jpg";
  }